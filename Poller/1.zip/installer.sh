#INSTALL PIP IF NOT YET INSTALLED
echo "====================================================="
echo "Install Python Libararies and requirements"
echo "====================================================="

# PIP INSTALLATION

sudo dnf install python3-pip > /dev/null


# NODEJS INSTALLATION

# Download and install nvm:
curl -o- https://raw.githubusercontent.com/nvm-sh/nvm/v0.40.3/install.sh | bash

# in lieu of restarting the shell
\. "$HOME/.nvm/nvm.sh"

# Download and install Node.js:
nvm install 24

# Verify the Node.js version:
node -v # Should print "v24.11.1".

# Verify npm version:
npm -v # Should print "11.6.2".



INSTALLATION_PROCESS_PIP() {
    pack=$1
    echo "INSTALLING: $pack ..."
    pip install "$pack" > /dev/null || { echo "Installation Error: $pack" >&2l exit  1;  }
}


#INSTALL
INSTALLATION_PROCESS_PIP asgiref==3.10.0
INSTALLATION_PROCESS_PIP cffi==2.0.0
INSTALLATION_PROCESS_PIP cryptography==46.0.3
INSTALLATION_PROCESS_PIP Django==4.2.25
INSTALLATION_PROCESS_PIP django-admin-interface==0.30.1
INSTALLATION_PROCESS_PIP django-colorfield==0.14.0
INSTALLATION_PROCESS_PIP django-environ==0.12.0
INSTALLATION_PROCESS_PIP mysqlclient==2.2.7
INSTALLATION_PROCESS_PIP pillow==11.3.0
INSTALLATION_PROCESS_PIP pycparser==2.23
INSTALLATION_PROCESS_PIP PyMySQL==1.1.2
INSTALLATION_PROCESS_PIP python-slugify==8.0.4
INSTALLATION_PROCESS_PIP sqlparse==0.5.3 
INSTALLATION_PROCESS_PIP text-unidecode==1.3
INSTALLATION_PROCESS_PIP typing_extensions==4.15.0
INSTALLATION_PROCESS_PIP djangorestframework==3.15.2
INSTALLATION_PROCESS_PIP django-cors-headers


# -------------------------------------------------------------------------------------------------------------------------

echo " Start Installing Poller Service ..."


DIR="/var/scripts"

if [ -d "$DIR" ]; then


echo "====================================================="
echo " "
echo "Poller Directory is already Exist... "
echo " "

else 

echo "====================================================="
echo " "
    #Make Directory for Poller scripts
mkdir -p /var/scripts/
echo "Preparing for Poller Directory ..."

fi



echo "====================================================="
echo " "
echo "Parsing Resouces ... "
cp -f scripts/* /var/scripts/
echo "Installation of Poller Resrouce was Finished ..."
echo " "

SERVICE="/etc/systemd/system/airnav_poller.service"

if [ -f "$SERVICE" ]; then

echo "====================================================="
echo " "
echo "The Service Already Exist... "
echo " "
echo "====================================================="

else 

echo "====================================================="
echo " "
echo "Creating Service "
    #Make Directory for Poller scripts
sudo tee /etc/systemd/system/airnav_poller.service <<EOF
[Unit]
Description=AIRNAV | Network Device Poller Using SNMPv3

[Service]
Type=simple
ExecStart=/usr/bin/python /var/scripts/poller.py
WorkingDirectory=/var/scripts
Restart=always
RestartSec=5
User=root
StandardOutput=append:/var/log/poller.log
StandardError=append:/var/log/poller.log

[Install]
WantedBy=multi-user.target    
EOF


echo "SERVICE Created!..."


sudo systemctl daemon-reload
sudo systemctl start airnav_poller.service
sudo systemctl enable --now airnav_poller.service


echo " "
echo "====================================================="


fi

# echo "Create CRON ...."
# (crontab -l 2>/dev/null; echo "*/5 * * * * /var/scripts2/poller.py") | crontab -
# echo "Successfully created CRON ...."
# -------------------------------------------------------------------------------------------------------------------------


#DASHBOARD






